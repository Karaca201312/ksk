import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:pedometer/pedometer.dart';
import 'package:fl_chart/fl_chart.dart';

void main() {
  runApp(SuFitApp());
}

class SuFitApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SuFit',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Sans',
      ),
      home: DashboardScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int dailyWaterIntake = 0; // ml
  int waterGoal = 2000; // ml
  int stepsToday = 0;
  int stepGoal = 8000;
  List<TimeOfDay> reminderTimes = [];

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  late Stream<StepCount> _stepCountStream;

  List<int> weeklyWaterIntake = [1500, 1800, 2000, 1700, 1900, 1600, 2100];

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
    _startStepCounting();
  }

  void _initializeNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initializationSettings = InitializationSettings(android: initializationSettingsAndroid);
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  void _startStepCounting() {
    _stepCountStream = Pedometer.stepCountStream;
    _stepCountStream.listen(
      (StepCount event) {
        setState(() {
          stepsToday = event.steps;
        });
      },
      onError: (error) {
        print('Adım sayar hatası: $error');
      },
    );
  }

  void addReminder(TimeOfDay time) {
    setState(() {
      reminderTimes.add(time);
    });
    _scheduleNotification(time);
  }

  Future<void> _scheduleNotification(TimeOfDay time) async {
    final androidDetails = AndroidNotificationDetails(
      'water_reminder_channel',
      'Su Hatırlatıcı',
      channelDescription: 'Belirli saatlerde su içmeyi hatırlatır',
      importance: Importance.max,
      priority: Priority.high,
    );

    final notificationDetails = NotificationDetails(android: androidDetails);
    final selectedDateTime = DateTime(
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
      time.hour,
      time.minute,
    );

    await flutterLocalNotificationsPlugin.zonedSchedule(
      selectedDateTime.hashCode,
      'Su İçme Zamanı',
      'Haydi, bir bardak su iç!',
      selectedDateTime.toUtc().add(const Duration(hours: 3)),
      notificationDetails,
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  void addWater(int amount) {
    setState(() {
      dailyWaterIntake += amount;
      if (dailyWaterIntake > waterGoal) dailyWaterIntake = waterGoal;
    });
  }

  double get waterProgress => dailyWaterIntake / waterGoal;
  double get stepProgress => stepsToday / stepGoal;

  void _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      addReminder(picked);
    }
  }

  Widget buildChart() {
    return AspectRatio(
      aspectRatio: 1.7,
      child: BarChart(
        BarChartData(
          barGroups: List.generate(
            weeklyWaterIntake.length,
            (index) => BarChartGroupData(
              x: index,
              barRods: [
                BarChartRodData(toY: weeklyWaterIntake[index].toDouble(), color: Colors.blue),
              ],
            ),
          ),
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
                  return Text(
                    days[value.toInt() % days.length],
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: true, reservedSize: 28),
            ),
          ),
          borderData: FlBorderData(show: false),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SuFit'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.alarm),
            onPressed: () => _selectTime(context),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text('Günlük Su Hedefi', style: TextStyle(fontSize: 18)),
            LinearProgressIndicator(value: waterProgress),
            SizedBox(height: 8),
            Text('$dailyWaterIntake ml / $waterGoal ml'),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(onPressed: () => addWater(100), child: Text('+100ml')),
                ElevatedButton(onPressed: () => addWater(250), child: Text('+250ml')),
                ElevatedButton(onPressed: () => addWater(500), child: Text('+500ml')),
              ],
            ),
            SizedBox(height: 24),
            Text('Adım Takibi', style: TextStyle(fontSize: 18)),
            LinearProgressIndicator(value: stepProgress),
            SizedBox(height: 8),
            Text('$stepsToday / $stepGoal adım'),
            SizedBox(height: 24),
            Text('Haftalık Su Tüketimi', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            buildChart(),
            SizedBox(height: 24),
            Text('Hatırlatıcı Saatleri', style: TextStyle(fontSize: 18)),
            for (final time in reminderTimes)
              Text('${time.format(context)}', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
